function myCoolFunction () {
  return 42
}
module.exports = {
  doSomething () {
    return myCoolFunction()
  }
}
